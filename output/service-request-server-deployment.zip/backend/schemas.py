"""Pydantic schemas for request/response validation."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


class _StripNonEmptyStrings(BaseModel):
    @field_validator("request_number", "department", "status", mode="before", check_fields=False)
    @classmethod
    def strip_non_empty_strings(cls, value):
        if value is None:
            return value
        if not isinstance(value, str):
            return value
        value = value.strip()
        if not value:
            raise ValueError("must not be blank")
        return value


class RequestCreate(_StripNonEmptyStrings):
    request_number: str = Field(..., min_length=1, max_length=64)
    department: str = Field(..., min_length=1, max_length=128)
    status: str = Field(default="open", min_length=1, max_length=64)
    data: dict[str, Any] | None = None


class RequestUpdate(_StripNonEmptyStrings):
    request_number: str | None = Field(default=None, min_length=1, max_length=64)
    department: str | None = Field(default=None, min_length=1, max_length=128)
    status: str | None = Field(default=None, min_length=1, max_length=64)
    data: dict[str, Any] | None = None


class RequestResponse(BaseModel):
    id: UUID
    request_number: str
    department: str
    status: str
    data: dict[str, Any] | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class HealthResponse(BaseModel):
    status: str


class ListResponse(BaseModel):
    items: list[RequestResponse]
    total: int
    limit: int
    offset: int
