"""FastAPI application entry point."""

from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import Depends, FastAPI, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db, init_db
from .models import AuditLog, ServiceRequest
from .schemas import (
    HealthResponse,
    ListResponse,
    RequestCreate,
    RequestResponse,
    RequestUpdate,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(
    title="Service Request API",
    version="0.1.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health", response_model=HealthResponse)
async def health(db: AsyncSession = Depends(get_db)):
    await db.execute(select(func.count()).select_from(ServiceRequest))
    return HealthResponse(status="ok")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _audit_snapshot(sr: ServiceRequest) -> dict:
    return {
        "request_number": sr.request_number,
        "department": sr.department,
        "status": sr.status,
        "data": sr.data,
    }


async def _write_audit(
    db: AsyncSession, action: str, sr: ServiceRequest, old: dict | None = None
):
    audit = AuditLog(
        action=action,
        request_id=sr.id,
        old_data=old,
        new_data=_audit_snapshot(sr),
    )
    db.add(audit)


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------

@app.post("/api/requests", response_model=RequestResponse, status_code=201)
async def create_request(body: RequestCreate, db: AsyncSession = Depends(get_db)):
    sr = ServiceRequest(
        request_number=body.request_number.strip(),
        department=body.department.strip(),
        status=body.status.strip(),
        data=body.data or {},
    )
    db.add(sr)
    try:
        await db.flush()
        await _write_audit(db, "create", sr)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="Duplicate request_number")
    await db.refresh(sr)
    return sr


@app.get("/api/requests", response_model=ListResponse)
async def list_requests(
    department: str | None = Query(default=None),
    status: str | None = Query(default=None),
    q: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(ServiceRequest)
    count_stmt = select(func.count()).select_from(ServiceRequest)

    if department:
        stmt = stmt.where(ServiceRequest.department == department)
        count_stmt = count_stmt.where(ServiceRequest.department == department)
    if status:
        stmt = stmt.where(ServiceRequest.status == status)
        count_stmt = count_stmt.where(ServiceRequest.status == status)
    if q:
        pattern = f"%{q}%"
        stmt = stmt.where(ServiceRequest.request_number.ilike(pattern))
        count_stmt = count_stmt.where(ServiceRequest.request_number.ilike(pattern))

    total = (await db.execute(count_stmt)).scalar() or 0
    stmt = stmt.order_by(ServiceRequest.created_at.desc()).offset(offset).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()

    return ListResponse(
        items=[RequestResponse.model_validate(r) for r in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@app.get("/api/requests/{request_id}", response_model=RequestResponse)
async def get_request(request_id: str, db: AsyncSession = Depends(get_db)):
    from uuid import UUID

    try:
        uid = UUID(request_id)
    except ValueError:
        raise HTTPException(status_code=422, detail="Invalid UUID")
    sr = await db.get(ServiceRequest, uid)
    if sr is None:
        raise HTTPException(status_code=404, detail="Not found")
    return sr


@app.patch("/api/requests/{request_id}", response_model=RequestResponse)
async def update_request(
    request_id: str, body: RequestUpdate, db: AsyncSession = Depends(get_db)
):
    from uuid import UUID

    try:
        uid = UUID(request_id)
    except ValueError:
        raise HTTPException(status_code=422, detail="Invalid UUID")
    sr = await db.get(ServiceRequest, uid)
    if sr is None:
        raise HTTPException(status_code=404, detail="Not found")

    old = _audit_snapshot(sr)

    if body.request_number is not None:
        sr.request_number = body.request_number.strip()
    if body.department is not None:
        sr.department = body.department.strip()
    if body.status is not None:
        sr.status = body.status.strip()
    if body.data is not None:
        sr.data = body.data

    sr.updated_at = datetime.now(timezone.utc)
    try:
        await db.flush()
        await _write_audit(db, "update", sr, old=old)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="Duplicate request_number")
    await db.refresh(sr)
    return sr
