# API Deployment Stack

One-button Docker deployment for the API + PostgreSQL backend.

## Prerequisites

| Requirement | Details |
|---|---|
| **Docker Desktop** | Windows with WSL 2 backend enabled. [Install](https://docs.docker.com/desktop/install/windows-install/) |
| **Docker Compose** | Included with Docker Desktop v2.17+ (Compose v2 plugin) |
| **RAM** | Minimum 4 GB free for containers |
| **Disk** | ~1 GB for images + database volume |

> **No Python, Node.js, or other runtimes required on the host.**  
> Everything runs inside Docker containers.

### Firewall Note (LAN Access)

By default the API is exposed on port `8080` (configurable in `.env`).  
To allow other machines on your LAN to connect:

1. Open **Windows Defender Firewall** > **Advanced Settings**
2. Create an **Inbound Rule** > **Port** > **TCP 8080**
3. Allow the connection for your network profile

Other machines can then reach the API at: `http://<server-ip>:8080`

## Quick Start

### First Deployment

1. **Double-click `deploy.bat`**

   This will:
   - Verify Docker CLI, Compose, and daemon are available
   - Generate `.env` with a cryptographically random PostgreSQL password
   - Build the API image
   - Start PostgreSQL + API containers
   - Wait for both to be healthy
   - Run a smoke test (health, create, retrieve, list)

2. **Done!** The API is running at `http://localhost:8080`  
   API docs: `http://localhost:8080/docs`

### Repeated Deployment

Double-click `deploy.bat` again. It is **idempotent**:
- Existing `.env` is never overwritten
- PostgreSQL data volume is preserved
- Services are updated/restarted safely

### Force Rebuild

```
deploy.bat --rebuild
```

Rebuilds the API image from scratch (ignores Docker cache).

### Skip Smoke Test

```
deploy.bat --no-smoke
```

Automation can add `--no-pause`; normal double-click use still pauses so the
deployment result remains visible.

## Available Commands

All commands are PowerShell scripts in the `scripts/` directory.

| Action | Command | Description |
|---|---|---|
| **Deploy** | `.\deploy.bat` | Full deployment with smoke test |
| **Status** | `.\scripts\status.ps1` | Show container status and health |
| **Logs** | `.\scripts\logs.ps1` | View recent logs (tail) |
| **Logs (follow)** | `.\scripts\logs.ps1 -Follow` | Continuously follow logs |
| **Logs (api only)** | `.\scripts\logs.ps1 -Service api` | API logs only |
| **Stop** | `.\scripts\stop.ps1` | Stop containers (data preserved) |
| **Stop + remove** | `.\scripts\stop.ps1 -RemoveContainers` | Stop and remove containers |
| **Backup** | `.\scripts\backup.ps1` | Dump database to `backups/` |
| **Restore** | `.\scripts\restore.ps1 -InputPath <file>` | Restore from backup |
| **Regenerate .env** | `.\scripts\generate-env.ps1 -Force` | New password (old data needs re-credentialing) |

## Configuration

Edit `.env` to change settings (requires `deploy.bat` restart):

| Variable | Default | Description |
|---|---|---|
| `POSTGRES_DB` | `appdb` | Database name |
| `POSTGRES_USER` | `appuser` | Database user |
| `POSTGRES_PASSWORD` | *(auto-generated)* | Database password (24 chars, cryptographically random) |
| `API_PORT` | `8080` | Host port for the API |

## Backup and Restore

### Backup

```powershell
.\scripts\backup.ps1
```

Creates a custom-format dump in `backups/` with timestamp.  
The backup runs inside the database container (no host PostgreSQL client needed).

**Custom output path:**
```powershell
.\scripts\backup.ps1 -OutputPath "D:\backups\api-full.dump"
```

### Restore

```powershell
.\scripts\restore.ps1 -InputPath "backups\appdb_2026-08-27_150101.dump" -Confirm
```

- Requires typing `RESTORE` or passing `-Confirm` for controlled automation
- Stops the API to prevent writes during restoration
- Replaces the application tables inside one PostgreSQL transaction
- Rolls back and exits with an error if restoration fails

**Important:** Always back up before restoring. Restore replaces the current application data.

## Architecture

```
docker-compose.yml
├── db (PostgreSQL 16.4-alpine)
│   ├── Named volume: app-pgdata
│   ├── Healthcheck: pg_isready
│   └── Internal network only (no LAN exposure)
│
└── api (FastAPI on Python 3.12)
    ├── Builds from: backend/Dockerfile
    ├── Depends on: db (healthy)
    ├── Port: ${API_PORT}:8000
    ├── Healthcheck: GET /health
    └── Network: app-backend-net
```

## File Structure

```
.
├── deploy.bat                 # One-button entry point
├── docker-compose.yml         # Service definitions
├── .env                       # Generated credentials (git-ignored)
├── .env.example               # Template for manual setup
├── .gitignore                 # Ignores .env, backups/
├── README.md                  # This file
│
├── backend/
│   └── Dockerfile             # API container build
│
└── scripts/
    ├── deploy.ps1             # Main deployment orchestrator
    ├── generate-env.ps1       # Secure .env generator
    ├── stop.ps1               # Stop services
    ├── status.ps1             # Show status/health
    ├── logs.ps1               # View logs
    ├── backup.ps1             # Database backup
    └── restore.ps1            # Database restore
```

## Troubleshooting

### "Docker daemon is not running"
Start Docker Desktop from the Start menu, or run:
```powershell
Start-Service docker
```

### "Health check failed"
Check API logs:
```powershell
.\scripts\logs.ps1 -Service api
```

### Database connection errors
Ensure the database container is healthy:
```powershell
docker inspect --format='{{.State.Health.Status}}' app-db
```

### Port 8080 already in use
Change `API_PORT` in `.env`:
```
API_PORT=9090
```

### LAN access not working
Check Windows Firewall allows inbound TCP on your configured port.
